<?php

$connect=mysql_connect("localhost","root","861994");
mysql_select_db("fst");
?>
